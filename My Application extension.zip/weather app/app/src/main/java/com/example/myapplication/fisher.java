package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import android.os.Bundle;

public class fisher extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener{

    private ImageView image;
    private ImageView image2;
    SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
    Date curDate = new Date(System.currentTimeMillis());
    String str = formatter.format(curDate);
    //抓時間，切換天氣和風速預報
    Calendar mCal = Calendar.getInstance();
    CharSequence s = DateFormat.format("MM/dd", mCal.getTime());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fisher);
        image = (ImageView) findViewById(R.id.imageView);
        image.setImageResource(R.mipmap.sunny2);
        TextView time = (TextView) findViewById(R.id.timeOutput);
        RadioGroup rg = findViewById(R.id.rgType);
        rg.setOnCheckedChangeListener(this);
        time = findViewById(R.id.timeOutput);
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
        Date curDate = new Date(System.currentTimeMillis());
        String str = formatter.format(curDate);
        time.setText(str);
        TextView day = (TextView) findViewById(R.id.dayOutput);
        day.setText(s);
    }

    public void onCheckedChanged (RadioGroup radioGroup,int i){
        switch (i) {
            case R.id.rdbWeather:
                image2.setImageResource(R.mipmap.weather);
                break;


            case R.id.rdbWind:
                image2.setImageResource(R.mipmap.wind);
                break;
        }
    }
}