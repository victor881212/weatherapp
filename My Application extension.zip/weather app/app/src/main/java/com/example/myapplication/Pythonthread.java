package com.example.myapplication;

import android.os.Bundle;
import android.os.Message;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class Pythonthread extends Thread{

    public void run(){
        try {
            Python py = Python.getInstance();
            py.getModule("data").callAttr("getdata");
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }
}
