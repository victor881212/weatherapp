package com.example.myapplication;

import android.app.Application;
import android.location.Location;

import java.util.ArrayList;
import java.util.List;

public class baogao12 extends Application {
    private static baogao12 singleton;

    private List<Location> myLocations;

    private List<String> pointname;

    public List<Location> getMyLocations() {
        return myLocations;
    }

    public List<String> getMyPointers() {
        return pointname;
    }

    public void setMyLocations(List<Location> myLocations) {
        baogao12.this.myLocations = myLocations;
    }

    public void setMyPointers(List<String> pointers) {
        baogao12.this.pointname = pointers;
    }
    public static baogao12 getInstance() {
        return singleton;
    }
    public void onCreate(){
        super.onCreate();
        singleton=this;
        myLocations = new ArrayList<>();
        pointname = new ArrayList<>();
    }
}
