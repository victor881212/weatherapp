package com.example.myapplication;
import android.util.Log;

import org.jsoup.Jsoup;
import java.io.IOException;

public class weatherdata_jsoup {

    public String catchdata(){
        String url="https://opendata.cwb.gov.tw/api/v1/rest/datastore/O-A0001-001?Authorization=CWB-F8BA6C07-0432-4495-843F-362332E65D59&format=JSON";
        String doc = null;
        try {
            doc=Jsoup.connect("https://www.fiverr.com/conversations/Json")
                    .timeout(1000000)
                    .header("Accept", "text/javascript")
                    .userAgent("Mozilla/5.0 (Windows NT 6.1; rv:40.0) Gecko/20100101 Firefox/40.0")
                    .get()
                    .body()
                    .text();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.i(doc,"test");
        return doc;
    }



}
