package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class locationlist extends AppCompatActivity {
    private ArrayList<HashMap<String,String>> list = new ArrayList<HashMap<String,String>>();
    //使用List存入HashMap，用來顯示ListView上面的文字。
    private SimpleAdapter simpleAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locationlist);
        //宣告物件id
        ListView lv_savedLocations = findViewById(R.id.lv_wayPoints);
        //使用List存入HashMap，用來顯示ListView上面的文字。
        List<HashMap<String, String>> list = new ArrayList<>();
        //索取資料
        baogao12 Baogao12 = (baogao12) getApplicationContext();
        List<Location> savedLocations = Baogao12.getMyLocations();
        List<String> savedPointers = Baogao12.getMyPointers();
        for (int i = 0; i < savedPointers.size(); i++) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("title", savedPointers.get(i));
            hashMap.put("position", savedLocations.get(i).toString());
            //把title , text存入HashMap之中
            list.add(hashMap);
            //把HashMap存入list之中
        }
        ListAdapter listAdapter = new SimpleAdapter(
                this,
                list,
                android.R.layout.simple_list_item_2,
                new String[]{"title", "position"},
                new int[]{android.R.id.text1, android.R.id.text2});
        lv_savedLocations.setAdapter(listAdapter);
        lv_savedLocations.setTextFilterEnabled(true);
        lv_savedLocations.setOnItemClickListener(showMap);
    }
    //選項事件
    private AdapterView.OnItemClickListener showMap = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
            // Toast 快顯功能 第三個參數 Toast.LENGTH_SHORT 2秒  LENGTH_LONG 5秒\
            baogao12 Baogao12 = (baogao12) getApplicationContext();
            List<String> savedPointers = Baogao12.getMyPointers();
            Toast.makeText(locationlist.this, "點選第 " + (position + 1) + " 個 \n記錄點：" + savedPointers.get(position).toString(), Toast.LENGTH_SHORT).show();
            AlertDialog.Builder builder = new AlertDialog.Builder(locationlist.this);
            builder.setTitle("提醒！").setIcon(R.mipmap.ic_launcher).setMessage("確認刪除此記錄點？").setPositiveButton("OK",new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            baogao12 Baogao12 = (baogao12) getApplicationContext();
                            List<String> savedPointers = Baogao12.getMyPointers();
                            List<Location> savedLocations=Baogao12.getMyLocations();
                            savedLocations.remove(position);
                            savedPointers.remove(position);
                            Baogao12.setMyPointers(savedPointers);
                            Baogao12.setMyLocations(savedLocations);
                            Toast.makeText(locationlist.this,"已刪除記錄點",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            overridePendingTransition(0, 0);
                        }
                    })
                    .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                            Toast.makeText(locationlist.this,"記錄點保留",Toast.LENGTH_SHORT).show();
                        }
                    });
            AlertDialog ad = builder.create();
            ad.show();

        }
    };

}