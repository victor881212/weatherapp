package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import com.facebook.stetho.Stetho;

import java.util.ArrayList;
import java.util.HashMap;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    String TAG = MainActivity.class.getSimpleName() + "My";
    private final String DB_NAME = "mojim.db";
    private String TABLE_NAME = "quality";
    private String TABLE_NAME2 = "weather";
    private String TABLE_NAME3 = "ultraviolet";
    private String TABLE_NAME4 = "forecast";
    private final int DB_VERSION = 1;
    SQLiteDataBaseHelper mDBHelper;

    ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();//取得所有資料
    ArrayList<HashMap<String, String>> getNowArray = new ArrayList<>();//取得被選中的項目資料
    private TextView Output;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Stetho.initializeWithDefaults(this);
        mDBHelper = new SQLiteDataBaseHelper(this, DB_NAME
                , null, DB_VERSION, TABLE_NAME);//初始化資料庫
        TextView Output =(TextView) findViewById(R.id.textView);
        //mDBHelper.addData("Sam","0912-345678","爬山","none");
        Log.d(TAG, "onCreate: "+mDBHelper.showAll());
        Output.setText(mDBHelper.showAll().toString());
        //mDBHelper.deleteByIdEZ("0");
        //mDBHelper.deletetable();
        if (!Python.isStarted()){
            Python.start(new AndroidPlatform(this));
        }
        Python py =Python.getInstance();
        py.getModule("hello").callAttr("sayhello");//python可以跑，但是python sqllite3資料庫不能直接在android使用

        //py.getModule("data").callAttr("getdata");
        //Output.setText(mDBHelper.showAll().toString());
        Button btn = (Button) findViewById(R.id.button2);
        btn.setOnClickListener(this);
    }

    public void btn_togetdata(View view){
        Thread t1 = new com.example.myapplication.Pythonthread();
        t1.start();
    }

    public void btn_showdata(View view) {}
    //    Python py = Python.getInstance();
    //    PyObject obj = py.getModule("data_process").callAttr("tostring", 3);
    //    String data1 = obj.toString();
    //    Output.setText(data1);
    //}


    @Override
    public void onClick(View view) {
        Output = (TextView) findViewById(R.id.textView);
        Python py = Python.getInstance();
        PyObject obj1 = py.getModule("data_process").callAttr("tostring", 3);
        String data1 = obj1.toJava(String.class);
        Output.setText(""+data1);
    }

    public void btn_tourists(View view){
        Intent intenttourists = new Intent(this,tourists.class);
        startActivity(intenttourists);

    }
    public void btn_tofisher(View view){
        Intent intenttourists = new Intent(this,fisher.class);
        startActivity(intenttourists);

    }
    public void btn_tomap(View view){
        Intent intenttourists = new Intent(this,map.class);
        startActivity(intenttourists);

    }
}