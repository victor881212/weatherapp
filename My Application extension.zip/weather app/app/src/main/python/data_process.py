import sqlite3
import os.path
#from java import jclass
#Intent = jclass('android.content.Intent')
#uri = jclass('android.net.Uri')
#intent = Intent(Intent.MainActivity.onClick)
#intent.setData(uri.parse("tel:" + "505"))
#Intent.startActivity(intent)
package_dir = os.path.abspath(os.path.dirname(__file__))
dbfile = os.path.join(package_dir, 'mojim.db')
country=['臺北市','新北市','基隆市','桃園市','新竹縣','宜蘭縣','苗栗縣','臺中市',
         '彰化縣','南投縣','雲林縣','高雄市','臺南市','嘉義縣','屏東縣','花蓮縣','臺東縣','澎湖縣','金門縣','連江縣']
def weather_process(CITY): #0 weather: #1 forecast: #2 ultraviolet: #3 quality:
    alltype = ['weather','thsixhour','ultraviolet','quality']
    relist = []
    if(isinstance(CITY,str)):
        for i in alltype:
            try:
                relist.append(tidy_to_one(country.index(CITY),i))
            except:
                return '輸入錯誤！'
        return relist
    if(isinstance(CITY,int)):
        print("city is int")
        for i in alltype:
            try:
                relist.append(tidy_to_one(int(CITY),i))
            except:
                return '輸入錯誤！'
        return relist




def tidy_up(select,type):
    conn = sqlite3.connect(dbfile) # 建立資料庫連線
    cursor = conn.execute
    try:
        cursor = conn.execute('SELECT * FROM '+type)
    except:
        print("nodata")
    #0臺北市,1新北市,2基隆市,3桃園市,4新竹縣,5宜蘭縣,6苗栗縣,7臺中市,8彰化縣,9南投縣,10雲林縣,11高雄市,12臺南市,13嘉義縣,14屏東縣,15花蓮縣,16臺東縣,17澎湖縣,18金門縣,19連江縣
    listselect=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]
    filter=['臺北市','新北市','基隆市','桃園市','新竹縣','宜蘭縣','苗栗縣','臺中市',
            '彰化縣','南投縣','雲林縣','高雄市','臺南市','嘉義縣','屏東縣','花蓮縣','臺東縣','澎湖縣','金門縣','連江縣'] #刪除'新竹市''嘉義市'
    list0=[]
    try:
        for record in cursor:
            for element in record:
                if(element==filter[select]):
                    list0.append(record)
    except:
        print("select is not in index")
    conn.close() # 關閉資料庫連線
    return list0

def tidy_to_one(select,type):
    countrylist=tidy_up(select,type)
    if countrylist==None:
        return
    counter=0
    relist=[None,None,None,None,None,None,None,None,None,None]
    errlist=[0,0,0,0,0,0,0,0,0,0]
    for record in countrylist:
        for element in record:
            addr=record.index(element)
            if isinstance(element,str):
                relist[addr]=element
            if isinstance(element,float):
                try:
                    if(element<0):
                        errlist[addr]+=1
                    else:
                        if(relist[addr] == None):relist[addr]=element
                        else:relist[addr]+=element
                except:
                    print("element can not pluse")
        counter+=1
    try:
        while (relist.index(None) !=None):
            relist.pop(-1)
    except:
        print(type + 'is processed')
    for i in range(len(relist)):
        if isinstance(relist[i],float):
            relist[i]=relist[i]/(counter-errlist[i])
    return relist

def deletesame(list0):
    relist = []
    for i in list0:
        try:
            for j in i:
                print(j)                         #兩層lsit
                if(isinstance(j,str)):
                    if(relist.count(j)<1):
                        relist.append(j)
                else:
                    relist.append(j)
        except:             #單層list
            if(isinstance(i,str)):
                if(relist.count(i)<0):
                    relist.append(i)
                else:
                    relist.append(i)
            if(relist[7]<2):
                relist[7]="弱"
            elif(relist[7]<5):
                relist[7]="中"
            else:
                relist[7]="強，出門記得做好防曬準備"

            if(relist[3]==0):
                relist[4]="無雨"
            elif(relist[3]<40):
                relist[4]="小雨"
            elif(relist[3]<60):
                relist[4]="大雨"
            else:
                relist[4]="豪雨"

            if(relist[9]<50):
                relist[10]="良好"
            elif(relist[9]<100):
                relist[10]="普通"
            elif(relist[9]<150):
                relist[10]="對敏感族群不良，出門建議戴口罩"
            elif(relist[9]<200):
                relist[10]="對所有族群不良，出門記得戴口罩"
            elif(relist[9]<300):
                relist[10]="非常不良，出門記得戴口罩"
            else:
                relist[10]="有害，出門必須戴口罩"
    return relist

def tostring(city): # 0city-1℃-2humidity-3rainfall-6grade#豪雨-5weather#陰有雨-4rain#降雨機率-7ultraviolet紫外線強度-8time時間-9aqi-10air空氣品質
    list0 = weather_process(city)
    list1 = deletesame(list0)
    #    if(list1[2]<50):
    #        list1[11]="今天適合曬衣服"
    #    elif(list1[2]>50 and list1[2]<70):
    #        list1[11]="衣服易滋生麈蟎"
    #    elif(list1[2]>70):
    #        list1[11]="衣服會生長霉菌"
    print(list1)
    return str(list1[8])+" "+str(list1[0])+"地區"+"天氣是:"+str(list1[4])+"，降雨機率"+str(list1[6])+"%，溫度是:"+str(list1[1])+"，濕度是:"+str(list1[2])+"，累積雨量達:"+str(list1[3])+"毫米，為"+str(list1[4])+"等級"+"，紫外線強度為:"+str(list1[7])+"，AQI:"+str(list1[9])+"，空氣品質"+str(list1[10])




def returntype(city,num):# 0city-1℃-2humidity-3rainfall-6grade#豪雨-5weather#陰有雨-4rain#降雨機率-7ultraviolet紫外線強度-8time時間-9aqi-10air空氣品質
    list1 = deletesame(weather_process(city))
    relist=""
    relist1=""
    relist2=""
    relist3=""
    relist4=""
    if(num==1):#曬衣服
        count=0
        if(list1[2]<70 and list1[2]>50):
            relist="濕氣重，衣服易滋生麈蟎"
            count+=2
        elif(list1[2]>=70):
            relist="濕氣重，衣服易生長霉菌"
            count+=3
        if(list1[6]>=40):
            relist1="容易下雨"
            count+=4
        if(list1[7]>1):
            relist2="沒太陽"
            count+=1
        if(count<=3):
            print(relist,relist1,relist2)
            return ("今天適合曬衣服")
        print(relist,relist1,relist2)
        return ("今天不適合曬衣服")
    if(num==2):#出門
        count1=0
        if(list1[1]<=16):
            relist="天冷加衣"
            count1+=1
        if(list1[7]>=6):
            relist1="注意防曬"
            count1+=1
        if(list1[6]>=40):
            relist2="容易下雨，記得帶傘"
            count1+=5
        if(list1[9]>100):
            relist3="空氣品質不佳"
            count1+=5
        if(count1<=4):
            print("今天適合出門")
            return relist+relist1+relist2+relist3
        print(("今天不適合出門"))
        return relist+relist1+relist2+relist3
    if(num==3):#穿搭
        count2=0
        count2=26-list1[1]
        if(count2>=15 and count2<18):
            relist="長褲+長袖衫+羽絨外套+手套+頸巾"#19
        if(count2>=12 and count2<15):
            relist="長褲+高領上衣+風衣外套+厚外套"#12
        if(count2>=9 and count2<12):
            relist="長褲+長袖衫+薄毛衣+厚外套"#10
        if(count2>=6 and count2<9):
            relist="長褲+高領上衣+風衣外套"#6
        if(count2>=3 and count2<6):
            relist="長褲+長袖衫+頸巾"
        if(count2>=0 and count2<3):
            relist="長褲+長袖衫"
        if(count2>=-14 and count2<0):
            relist="短褲+短袖"
        return relist
    if(num==4):#運動
        count3=0
        if(list1[9]>100):
            relist="空氣品質不佳"
            count3+=1
        if(list1[6]>=40):
            relist1="容易下雨"
            count3+=1
        if(list1[7]>=6):
            relist2="紫外線強度很強"
            count3+=1
        if(list1[2]>=80):
            relist3="相對溼度過高"
            count3+=1
        if(list1[1]>=31):
            relist4="氣溫過高，可能導致熱中暑"
            count3+=1
        if(count3<1):
            print(relist,relist1,relist2,relist3,relist4)
            return ("今天適合戶外運動")
        print(relist,relist1,relist2,relist3,relist4)
        return ("建議在家休息或進行室內運動")