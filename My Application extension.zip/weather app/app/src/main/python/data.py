import requests
import json
import sqlite3
import os.path
package_dir = os.path.abspath(os.path.dirname(__file__))
dbfile = os.path.join(package_dir, 'mojim.db')


def getdata():
    #url=['https://data.epa.gov.tw/api/v2/aqx_p_432?api_key=e8dd42e6-9b8b-43f8-991e-b3dee723a52d&limit=1000&sort=ImportDate%20desc&format=JSON',
    #'https://opendata.cwb.gov.tw/fileapi/v1/opendataapi/O-A0001-001?Authorization=CWB-786345A7-6464-4764-82F3-C719B3A81509&downloadType=WEB&format=JSON',
    #'https://data.epa.gov.tw/api/v2/uv_s_01?api_key=e8dd42e6-9b8b-43f8-991e-b3dee723a52d&limit=1000&sort=publishtime%20desc&format=JSON',
    #'https://opendata.cwb.gov.tw/fileapi/v1/opendataapi/F-C0032-001?Authorization=CWB-786345A7-6464-4764-82F3-C719B3A81509&downloadType=WEB&format=JSON']
    getair()
    getweather()
    get_ultraviole()
    get_forecast()
    print("data is get")

def getair():
    conn = sqlite3.connect(dbfile)
    url='https://data.epa.gov.tw/api/v2/aqx_p_432?api_key=e8dd42e6-9b8b-43f8-991e-b3dee723a52d&limit=1000&sort=ImportDate%20desc&format=JSON'
    try:
        conn.execute("DROP TABLE quality")
    except:
        print("file not find")
    c = conn.cursor()
    c.execute("""CREATE TABLE quality
    ("county"	TEXT NOT NULL,
	  "aqi"	REAL NOT NULL,
	  "air"	TEXT NOT NULL);""")
    data = requests.get(url)             # 使用 get 方法透過空氣品質指標 API 取得內容
    data_json = data.json()              # 將取得的檔案轉換為 JSON 格式
    for i in data_json['records']:       # 依序取出 records 內容的每個項目
        print(i['county'], end='，')    # 印出城市與地點名稱
        print('aqi:' + i['aqi'], end='，')                    # 印出 AQI 數值
        print('空氣品質' + i['status'])                        # 印出空氣品質狀態
        conn.execute("INSERT INTO quality (county, aqi, air)VALUES ('{}', {}, '{}')".format(i['county'], i['aqi'], i['status']))
    conn.commit()
    conn.close()

def getweather():
    conn = sqlite3.connect(dbfile)
    url='https://opendata.cwb.gov.tw/fileapi/v1/opendataapi/O-A0001-001?Authorization=CWB-786345A7-6464-4764-82F3-C719B3A81509&downloadType=WEB&format=JSON'
    try:
        conn.execute("DROP TABLE weather")
    except:
        print("file not find")
    a = conn.cursor()
    a.execute("""CREATE TABLE weather
    ("city" TEXT NOT NULL,
	  "℃" REAL NOT NULL,
	  "humidity" REAL NOT NULL,
      "rainfall" REAL NOT NULL,
      "grade" TEXT NOT NULL);""")
    data = requests.get(url)
    data_json = data.json()
    location = data_json['cwbopendata']['location']
    for i in location:
        #name = i['locationName']
        city = i['parameter'][0]['parameterValue'] ##縣市
        #area = i['parameter'][2]['parameterValue']
        temp = i['weatherElement'][3]['elementValue']['value'] #溫度
        humd = round(float(i['weatherElement'][4]['elementValue']['value'] )*100 ,1) #濕度
        r24 = i['weatherElement'][6]  ['elementValue']['value'] #雨量
        #msg = f'{temp} 度，相對濕度 {humd}%，累積雨量 {r24}mm'  # 組合成天氣描述
        f = float(r24)
        #print(city, end=' ')
        #print(temp, '度 相對溼度 ', humd, '% 累積雨量', end=' ')
        #print(r24, 'mm', end=' ')
        if f == 0:
            lv = "無雨"
        elif f >= 0 and f <= 40:
            lv = "小雨"
        elif f > 40 and f < 60:
            lv = "大雨"
        else:
            lv = "豪雨"
        #print(lv)
        conn.execute("INSERT INTO weather (city, ℃, humidity, rainfall, grade)VALUES ('{}', {}, {}, {}, '{}')".format(city, temp, humd, r24, lv))
    conn.commit()
    conn.close()

def get_ultraviole():
    conn = sqlite3.connect(dbfile)
    url='https://data.epa.gov.tw/api/v2/uv_s_01?api_key=e8dd42e6-9b8b-43f8-991e-b3dee723a52d&limit=1000&sort=publishtime%20desc&format=JSON'
    try:
        conn.execute("DROP TABLE ultraviolet")
    except:
        print("file not find")
    a = conn.cursor()
    a.execute("""CREATE TABLE ultraviolet
    ("city" TEXT NOT NULL,
	  "ultraviolet" REAL NOT NULL,
	  "time" TEXT NOT NULL);""")
    html = requests.get(url)
    dict1 = json.loads(html.text)
    list1 = dict1.get("records")
    s = "縣市, 發布機關, 測站名稱, 紫外線指數, 緯度, 經度\n"
    for dict in list1:
        list2 = list(dict.values())
        s = s + "{}, {}, {}, {}, {}, {}, {}\n".format(list2[0], list2[1], list2[2], list2[3], list2[4], list2[5], list2[6])
        answer=""
        answer+=list2[3]+" "
        answer+=list2[1]+" "
        answer+=list2[6]
        try:
            list2[1]=float(list2[1])
        except:
            list2[1]=0
        #print(list2[3], list2[1], list2[6])
        conn.execute("INSERT INTO ultraviolet (city, ultraviolet, time)VALUES ('{}', {}, '{}')".format(list2[3], float(list2[1]), list2[6]))
    conn.commit()
    conn.close()


def get_forecast():
    conn = sqlite3.connect(dbfile)
    try:
        conn.execute("DROP TABLE thsixhour")
    except:
        print("file not find")

    b = conn.cursor()
    b.execute("""CREATE TABLE thsixhour
        ("city" TEXT NOT NULL,
        "weather" TEXT NOT NULL,
        "rain" REAL NOT NULL);""")

    url = 'https://opendata.cwb.gov.tw/fileapi/v1/opendataapi/F-C0032-001?Authorization=CWB-786345A7-6464-4764-82F3-C719B3A81509&downloadType=WEB&format=JSON'
    data = requests.get(url)   # 取得 JSON 檔案的內容為文字
    data_json = data.json()    # 轉換成 JSON 格式
    location = data_json['cwbopendata']['dataset']['location']
    for i in location:
        city = i['locationName']    # 縣市名稱
        wx8 = i['weatherElement'][0]['time'][0]['parameter']['parameterName']    # 天氣現象
        maxt8 = i['weatherElement'][1]['time'][0]['parameter']['parameterName']  # 最高溫
        mint8 = i['weatherElement'][2]['time'][0]['parameter']['parameterName']  # 最低溫
        ci8 = i['weatherElement'][3]['time'][0]['parameter']['parameterName']    # 舒適度
        pop8 = i['weatherElement'][4]['time'][0]['parameter']['parameterName']   # 降雨機率
        #print(f'{city} {wx8}，降雨機率 {pop8} %')
        conn.execute("INSERT INTO thsixhour (city, weather, rain)VALUES ('{}', '{}', {})".format(city, wx8, pop8))
    conn.commit()
    conn.close()
getdata()