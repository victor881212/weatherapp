package com.example.homework;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private Spinner sp1;
    public static TextView textView,textView2,textView3,total;
    private ImageView image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String[] courses = {"新北市","桃園市","台中市","台南市","高雄市","基隆市","新竹縣","新竹市","苗栗縣","彰化縣","南投縣","雲林縣","嘉義縣","嘉義市","屏東縣","宜蘭縣","花蓮縣","台東縣","澎湖縣","金門縣","連江縣","總覽"};

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.weather);
        textView2 = findViewById(R.id.weather2);
        textView3 = findViewById(R.id.weather3);
        total = findViewById(R.id.total);

        Thread t1 = new otherThread();
        t1.start();

        sp1 = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> a1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,courses);
        sp1.setAdapter(a1);
        sp1.setOnItemSelectedListener(this);

        image = (ImageView) findViewById(R.id.imageView);

        /*textView.setText("臺北市 陰短暫雨，降雨機率 80 %\n" +
       0         "新北市 陰短暫雨，降雨機率 90 %\n" +
       1         "桃園市 陰短暫雨，降雨機率 80 %\n" +
       2         "臺中市 陰短暫雨，降雨機率 30 %\n" +
       3         "臺南市 陰短暫雨，降雨機率 30 %\n" +
       4         "高雄市 陰短暫雨，降雨機率 70 %\n" +
       5         "基隆市 陰短暫雨，降雨機率 90 %\n" +
       6         "新竹縣 陰短暫雨，降雨機率 70 %\n" +
       7         "新竹市 陰短暫雨，降雨機率 50 %\n" +
       8         "苗栗縣 陰短暫雨，降雨機率 30 %\n" +
       9         "彰化縣 陰短暫雨，降雨機率 30 %\n" +
       10        "南投縣 陰短暫雨，降雨機率 30 %\n" +
       11        "雲林縣 陰短暫雨，降雨機率 30 %\n" +
       12        "嘉義縣 陰短暫雨，降雨機率 30 %\n" +
       13        "嘉義市 陰短暫雨，降雨機率 30 %\n" +
       14        "屏東縣 陰短暫雨，降雨機率 80 %\n" +
       15        "宜蘭縣 陰短暫雨，降雨機率 30 %\n" +
       16        "花蓮縣 陰短暫雨，降雨機率 40 %\n" +
       17        "臺東縣 陰短暫雨，降雨機率 60 %\n" +
       18        "澎湖縣 陰短暫雨，降雨機率 30 %\n" +
       19        "金門縣 陰天，降雨機率 20 %\n" +
       20        "連江縣 多雲時晴，降雨機率 10 %");
       21         總覽*/
    }

    public static Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            Bundle gotMsg = msg.getData();
            //textView.setText(gotMsg.getString("output"));
        }
    };

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String where = sp1.getSelectedItem().toString();
        int index = sp1.getSelectedItemPosition();
        textView.setText(where);
        //天氣
        if(index == 19) {
            total.setText("");
            image.setImageResource(R.mipmap.w2);
            textView2.setText("陰天");
            image.setVisibility(View.VISIBLE);
        }
        else if(index == 20) {
            total.setText("");
            image.setImageResource(R.mipmap.w3);
            textView2.setText("多雲時晴");
            image.setVisibility(View.VISIBLE);
        }
        else {
            total.setText("");
            image.setImageResource(R.mipmap.w1);
            textView2.setText("陰短暫雨");
            image.setVisibility(View.VISIBLE);
        }
        //機率
        if(index == 0 || index == 5) {
            total.setText("");
            image.setVisibility(View.VISIBLE);
            textView3.setText("降雨機率:90%");
        }
        else if(index == 1 || index == 14) {
            total.setText("");
            image.setVisibility(View.VISIBLE);
            textView3.setText("降雨機率:80%");
        }
        else if(index == 4 || index == 6) {
            total.setText("");
            image.setVisibility(View.VISIBLE);
            textView3.setText("降雨機率:70%");
        }
        else if(index == 17) {
            total.setText("");
            image.setVisibility(View.VISIBLE);
            textView3.setText("降雨機率:60%");
        }
        else if(index == 7) {
            total.setText("");
            image.setVisibility(View.VISIBLE);
            textView3.setText("降雨機率:50%");
        }
        else if(index == 16) {
            total.setText("");
            image.setVisibility(View.VISIBLE);
            textView3.setText("降雨機率:40%");
        }
        else if(index == 19) {
            total.setText("");
            image.setVisibility(View.VISIBLE);
            textView3.setText("降雨機率:20%");
        }
        else if(index == 20) {
            total.setText("");
            image.setVisibility(View.VISIBLE);
            textView3.setText("降雨機率:10%");
        }
        else {
            total.setText("");
            image.setVisibility(View.VISIBLE);
            textView3.setText("降雨機率:30%");
        }
        //總覽
        if(index == 21){
            total.setText("臺北市 陰短暫雨，降雨機率 80 % 不建議\n" +
                          "新北市 陰短暫雨，降雨機率 90 % 不建議\n" +
                          "桃園市 陰短暫雨，降雨機率 80 % 不建議\n" +
                          "臺中市 陰短暫雨，降雨機率 30 % 不建議\n" +
                          "臺南市 陰短暫雨，降雨機率 30 % 不建議\n" +
                          "高雄市 陰短暫雨，降雨機率 70 % 不建議\n" +
                          "基隆市 陰短暫雨，降雨機率 90 % 不建議\n" +
                          "新竹縣 陰短暫雨，降雨機率 70 % 不建議\n" +
                          "新竹市 陰短暫雨，降雨機率 50 % 不建議\n" +
                          "苗栗縣 陰短暫雨，降雨機率 30 % 不建議\n" +
                          "彰化縣 陰短暫雨，降雨機率 30 % 不建議\n" +
                          "南投縣 陰短暫雨，降雨機率 30 % 不建議\n" +
                          "雲林縣 陰短暫雨，降雨機率 30 % 不建議\n" +
                          "嘉義縣 陰短暫雨，降雨機率 30 % 不建議\n" +
                          "嘉義市 陰短暫雨，降雨機率 30 % 不建議\n" +
                          "屏東縣 陰短暫雨，降雨機率 80 % 不建議\n" +
                          "宜蘭縣 陰短暫雨，降雨機率 30 % 不建議\n" +
                          "花蓮縣 陰短暫雨，降雨機率 40 % 不建議\n" +
                          "臺東縣 陰短暫雨，降雨機率 60 % 不建議\n" +
                          "澎湖縣 陰短暫雨，降雨機率 30 % 不建議\n" +
                          "金門縣 陰天，    降雨機率 20 %   建議\n" +
                          "連江縣 多雲時晴，降雨機率 10 %   建議\n" );
            textView.setText("");
            textView2.setText("");
            textView3.setText("");
            image.setVisibility(View.GONE);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
