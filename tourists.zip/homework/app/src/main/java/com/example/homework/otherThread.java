package com.example.homework;

import android.os.Bundle;
import android.os.Message;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

public class otherThread extends Thread{
    public void run(){
        try {
            String url = "https://opendata.cwb.gov.tw/api/v1/rest/datastore/F-C0032-001?Authorization=CWB-4DA32745-82F5-4AC6-8A6A-6EF645FCF3BB&elementName=PoP,MinT,MaxT";
            InputStream is = new URL(url).openStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is,"utf-8"));
            StringBuilder sb = new StringBuilder();
            int cp;
            while ((cp = rd.read()) != -1){
                sb.append((char) cp);
            }
            String weatherStr = sb.toString();
            System.out.println(sb.toString());
            Bundle carrier = new Bundle();
            carrier.putString("output",weatherStr);
            Message msg = new Message();
            msg.setData(carrier);
            MainActivity.mHandler.sendMessage(msg);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
